-- Examen práctico 1
-- Fecha: 29-04-2024
-- Carrera: Licenciatura en Ingeniería de Datos e Inteligencia Artificial
-- Semestre: 2024 Enero-Junio
-- Curso: Bases de Datos Relacionales
-- Autor: Alejandro Alonso Sánchez
-- Descripción: (muy breve descripción general del examen, sin paréntesis)

DROP DATABASE IF EXISTS dieta;
CREATE DATABASE IF NOT EXISTS dieta;
USE dieta;

CREATE TABLE IF NOT EXISTS paciente
(
	pac_id INT NOT NULL AUTO_INCREMENT,
	pac_nombre VARCHAR (20) NOT NULL,
    pac_ap_pat VARCHAR(20) NOT NULL,
    pac_ap_mat VARCHAR(20),
    pac_fecha_nac DATE NOT NULL,
    pac_estatura DECIMAL(3,2) NOT NULL COMMENT 'metros',
    pac_direccion VARCHAR(50) NOT NULL,
    pac_correo VARCHAR(35) NOT NULL,

	PRIMARY KEY(pac_id),
    UNIQUE uni_correo(pac_correo),
    UNIQUE uni_nom_dir(pac_nombre, pac_ap_pat, pac_direccion),
    INDEX idx_nombre (pac_nombre, pac_ap_pat, pac_ap_mat)
);

CREATE TABLE IF NOT EXISTS alimento
(
	ali_id INT NOT NULL AUTO_INCREMENT,
	ali_nombre VARCHAR(35) NOT NULL,
    ali_medida_porcion VARCHAR(35) NOT NULL,
    ali_tipo ENUM('frutas','verduras', 'carnes y proteinas', 'lácteos', 'granos y cereales', 'aceites y grasas') NOT NULL,
    ali_calorias_por_porcion INT UNSIGNED NOT NULL COMMENT 'kcal',
    ali_grasa_por_porcion INT UNSIGNED NOT NULL COMMENT 'gramos',
    ali_proteina_por_porcion  INT UNSIGNED NOT NULL COMMENT 'gramos',
    ali_carbos_por_porcion INT UNSIGNED NOT NULL COMMENT 'gramos',
    PRIMARY KEY(ali_id),
    UNIQUE uni_nom_med (ali_nombre, ali_medida_porcion),
	INDEX idx_nombre (ali_nombre),
    INDEX idx_cal (ali_calorias_por_porcion),
    INDEX idx_pro (ali_proteina_por_porcion)
);

CREATE TABLE IF NOT EXISTS evo_paciente
(
	evo_id INT NOT NULL,
    evo_fecha DATE NOT NULL COMMENT 'fecha de actualización',
    evo_peso DECIMAL(5,2) COMMENT 'kilogramos' NOT NULL,
	evo_imc DECIMAL(5,2) COMMENT 'KG / M^3' NOT NULL,
    evo_grasa DECIMAL(4,2) COMMENT '%' NOT NULL,
    evo_agua DECIMAL(4,2) COMMENT '%' NOT NULL,
    PRIMARY KEY (evo_id),
    INDEX idx_peso(evo_peso),
    CONSTRAINT fk_pac_id
		FOREIGN KEY (evo_id)
        REFERENCES paciente(pac_id)
        ON UPDATE CASCADE
		ON DELETE NO ACTION 
        # en caso de cambiar la información del paciente se debe reflejar aquí también, en caso de eliminarse
        # se pudo haber dado de baja por diversas razones, 
        # pero la información de aquí es valiosa para su estudio, ya sea que funcionó la dieta, no funcionó, etc
);

CREATE TABLE IF NOT EXISTS dieta
(
	die_id INT NOT NULL AUTO_INCREMENT,
	die_paciente_id INT NOT NULL,
    die_fecha_ini DATE NOT NULL,
    die_fecha_fin DATE,

    PRIMARY KEY (die_id, die_paciente_id),
    CONSTRAINT fk_paciente_id
    FOREIGN KEY (die_paciente_id)
		REFERENCES paciente(pac_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS detalle_dieta
(
	det_id INT NOT NULL AUTO_INCREMENT,
	det_tipo_comida ENUM('desayuno', 'comida', 'cena', 'colación') NOT NULL,
    det_num_porciones INT UNSIGNED,
    det_alimento_id INT NOT NULL,
    det_dieta_id INT NOT NULL,

    PRIMARY KEY (det_id),
	CONSTRAINT fk_det_alimento
		FOREIGN KEY (det_alimento_id)
		REFERENCES alimento(ali_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
	CONSTRAINT fk_det_dieta
    FOREIGN KEY (det_dieta_id)
		REFERENCES dieta(die_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
	# si se actualiza se debe reflejar dichos cambios, por ejemplo cálculos de calorías y demás
);

INSERT INTO paciente(pac_nombre,pac_ap_pat, pac_ap_mat, pac_fecha_nac, pac_estatura, pac_direccion, pac_correo)
	VALUES ('uno', 'Lopez', 'x', '1999-06-19', 1.75, 'revolucion 337', 'lopez@mail.com'),
     ('dos', 'sanchez', 'y', '2001-01-20', 1.50, 'alvaro obr 337', 'sanchez@mail.com'),
     ('tres', 'hernandez', 'z', '2002-02-20', 1.50, 'paseo camelias 337', 'hernandez@mail.com');

INSERT INTO alimento(ali_nombre, ali_medida_porcion, ali_tipo, ali_calorias_por_porcion, ali_grasa_por_porcion, ali_proteina_por_porcion, ali_carbos_por_porcion)
	VALUES ('aguacate', '1/2taza', 'verduras', '65', '10', '10', '10'),
    ('fresas', '1 taza', 'frutas', '50', '10', '10', '10'),
    ('kiwi', '1 taza', 'frutas', '50', '10', '10', '10'),
    ('pollo a la plancha', '1 taza', 'verduras', '65', '10', '10', '10'),
    ('cereal con yogur', '1 taza', 'granos y cereales', '65', '10', '10', '10');
    
INSERT INTO dieta(die_paciente_id, die_fecha_ini, die_fecha_fin)
	VALUES (1, '2024-03-01', '2024-3-31'),
	(1, '2024-04-01', '2024-4-30'),
	(2, '2024-03-01', '2024-3-31'),
	(2, '2024-04-01', '2024-4-30'),
	(3, '2024-03-01', '2024-3-31'),
	(3, '2024-04-01', '2024-4-30');
    
INSERT INTO detalle_dieta (det_tipo_comida, det_num_porciones, det_alimento_id, det_dieta_id)
	VALUES ('desayuno', '2', '1', '1'),
    ('desayuno', '2', '2', '1'),
    ('comida', '2', '3', '1'),
    ('cena', '2', '4', '1'),
    ('colación', '2', '5', '1'),
	('desayuno', '2', '1', '2'),
    ('desayuno', '2', '2', '2'),
    ('comida', '2', '3', '2'),
    ('cena', '2', '4', '2'),
    ('colación', '2', '5', '2'),
     ('desayuno', '2', '1', '3'),
    ('desayuno', '2', '2', '3'),
    ('comida', '2', '3', '3'),
    ('cena', '2', '4', '3'),
    ('colación', '2', '5', '3'),
	('desayuno', '2', '1', '4'),
    ('desayuno', '2', '2', '4'),
    ('comida', '2', '3', '4'),
    ('cena', '2', '4', '4'),
    ('colación', '2', '5', '4');
	
	
	
select * from detalle_dieta;

UPDATE dieta
SET die_fecha_ini = die_fecha_ini - WEEK - WEEK
WHERE(
		paciente(pac_ap_pat) LIKE '%ez'
		OR  paciente(pac_ap_pat) LIKE '%is'
		OR paciente(pac_ap_pat) LIKE '%co')
    OR
    (
		paciente(pac_ap_mat) LIKE '%ez'
		OR  paciente(pac_ap_mat) LIKE '%is'
		OR paciente(pac_ap_mat) LIKE '%co'
    )
    AND paciente(pac_estatura) BETWEEN 1.50 AND 1.90
    AND paciente(pac_fecha_nac) LIKE '%-06-%'
    AND paciente(pac_id) = pac_id;




    

    
